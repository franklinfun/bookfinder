import React, { useState } from 'react';
import SearchBar from '../components/SearchBar';
import BookCard from '../components/BookCard';
import Loader from '../components/Loader';

const Home = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (title) => {
    setLoading(true);
    setError('');
    setBooks([]);
    try {
      const res = await fetch(`https://openlibrary.org/search.json?title=${title}`);
      const data = await res.json();
      if (data.docs.length === 0) {
        setError('No books found.');
      } else {
        setBooks(data.docs.slice(0, 20));
      }
    } catch {
      setError('Something went wrong. Try again later.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold text-center text-blue-600">📚 Book Finder</h1>
      <SearchBar onSearch={handleSearch} />
      {loading && <Loader />}
      {error && <p className="text-center text-red-500">{error}</p>}
      <div className="flex flex-wrap justify-center gap-4 mt-6">
        {books.map((b, i) => (
          <BookCard key={i} book={b} />
        ))}
      </div>
    </div>
  );
};

export default Home;
