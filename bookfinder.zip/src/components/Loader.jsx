const Loader = () => (
  <div className="text-center my-10 text-blue-500 font-semibold animate-pulse">
    Loading...
  </div>
);
export default Loader;
