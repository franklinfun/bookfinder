const BookCard = ({ book }) => {
  const cover = book.cover_i
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`
    : 'https://via.placeholder.com/150x200?text=No+Cover';

  return (
    <div className="bg-white shadow-md rounded-xl p-4 flex flex-col items-center text-center w-48">
      <img src={cover} alt={book.title} className="h-48 w-full object-cover rounded" />
      <h3 className="text-sm font-semibold mt-2">{book.title}</h3>
      <p className="text-xs text-gray-500">{book.author_name?.[0] || 'Unknown Author'}</p>
      <p className="text-xs text-gray-400">📅 {book.first_publish_year || '-'}</p>
    </div>
  );
};

export default BookCard;
